#libraries
require("dplyr")
require("readxl")

library("dplyr")
library("readxl")

# file input e estrazione della dataframe
file_name = "C:/Users/amato/Documents/R/datasets/testingresso.csv"
data <- read.csv(file_name)

mod <- lm(data$punteggiofinale ~ data$votomat, data = data)

plot(x = data$votomat, y = data$punteggiofinale, xlab = "Maturita'", ylab = "Test")
abline(mod, col = "red")

# esecuzione manuale dei calcoli per ricavare i parametri di alpha (intercetta) e beta (pendenza)
mean_x = mean(data$votomat)
mean_y = mean(data$punteggiofinale)
covarianza = cov(data$votomat, data$punteggiofinale)
var_x = var(data$votomat)
beta = covarianza/var_x
alpha = mean_y - (beta * mean_x)

# tramite entrambi i metodi usati per calcolare il coefficiente di regressione, esso risulta essere:
# beta = 0.08
# i metodi usati sono stati:
# 1. calcolo dei coefficienti della regressione lineare tramite il modello lm() di R
# 2. calcolo dei coefficieni della regressione lineare tramite il calcolo manuale dei due valori alpha e beta
# 
# Nonostante la retta di regressione abbia una pendenza molto bassa, si pu� notare tramite il grafico come
# esista poca correlazione tra i due dati X (= voti alla maturit�) e Y (= voti al test). La retta ha comunque
# una pendenza crescente, quindi una leggera relazione che indica che al crescere di X cresce anche Y esiste.
# 
# Osservo inoltre che il valore di R^2 non � alto (0.05), il che significa che il modello non spiega bene 
# la relazione che sussiste tra X e Y.